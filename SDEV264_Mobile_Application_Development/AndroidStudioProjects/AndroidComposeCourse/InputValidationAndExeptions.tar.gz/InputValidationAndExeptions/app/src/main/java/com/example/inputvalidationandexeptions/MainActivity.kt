package com.example.inputvalidationandexeptions

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.inputvalidationandexeptions.ui.theme.InputValidationAndExeptionsTheme

const val MAIN_ACTIVITY_NAME = "MainActivity"
const val SLICES_PER_PIZZA = 8

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            InputValidationAndExeptionsTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    PizzaApp("Android")
                }
            }
        }
    }
}

@Composable
fun PizzaApp(name: String) {
    var peopleText by remember { mutableStateOf("1") }
    var pizzaText by remember { mutableStateOf("1") }

    Column (modifier = Modifier.fillMaxSize()) {
        Row() {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 40.dp)
            ) {
                Row() {
                    Text("Number of people:")
                    TextField(value = peopleText, onValueChange = {peopleText = it})
                }
                Row() {
                    Text("Number of pizzas:")
                    TextField(value = pizzaText, onValueChange = {pizzaText = it})
                }

                // Step1: fill in the onClick lambda
                Button(onClick = { DoPizzaCalculations(peopleText.toInt(), pizzaText.toInt()) } ) {
                    Text("Calculate")
                }
            }
        }
        Column(
            verticalArrangement = Arrangement.Bottom,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 40.dp)
        ) {
            Row { Text("Test slices per person result." ) }
            Row { Text("Test leftover result." ) }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 16.dp),
                horizontalArrangement = Arrangement.Center,
            ) { Text("Test error message.", color = MaterialTheme.colors.error) }
        }
    }
}

private fun DoPizzaCalculations(people: Int, pizzas: Int) {
    // Step2: simulate logging some messages when the app crashes
    try {
        val slicesPerPerson = CalculatePizzaPerPerson(people, pizzas)
        val leftover = CalculateLeftoverPizza(people, pizzas)
//    DisplayResults(slicesPerPerson, leftover)
    } catch (e: Exception) {
        Log.e(MAIN_ACTIVITY_NAME, "Exception: ${e.message}")
        Log.e(MAIN_ACTIVITY_NAME, "Stack trace: ${e.stackTrace}")
    }
}

private fun CalculatePizzaPerPerson(people: Int, pizzas: Int): Int {
    // Note: this will always return an integer result since we're doing integer division
    // It's the same as if we'd called: floor(pizzas * SLICES_PER_PIZZA / people)
    return (pizzas * SLICES_PER_PIZZA) / people
}

private fun CalculateLeftoverPizza(people: Int, pizzas: Int): Int {
    return (pizzas * SLICES_PER_PIZZA) % people
}

//@Preview(showBackground = true)
//@Composable
//fun DefaultPreview() {
//    InputValidationAndExeptionsTheme {
//        Greeting("Android")
//    }
//}