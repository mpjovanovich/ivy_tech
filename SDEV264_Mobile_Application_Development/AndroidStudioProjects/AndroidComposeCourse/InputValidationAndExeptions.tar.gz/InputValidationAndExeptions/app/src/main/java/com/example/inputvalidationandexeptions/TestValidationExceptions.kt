package com.example.inputvalidationandexeptions

class TestValidationExceptions {
    val SLICES_PER_PIZZA = 8

     fun test() {
        // Step2: We don't want the program to crash without showing some kind of error message.
        // Let's put in a try/catch block to handle all exceptions at the top level.
        try {
            // Prompt the user for input.
            val numberOfPeople = getPositiveIntegerInput("Enter the number of people: ")
            val numberOfPizzas = getPositiveIntegerInput("Enter the number of pizzas: ")

            // Calculate the slices per person and left over amounts.
            val numberOfSlices = numberOfPizzas * SLICES_PER_PIZZA
            val slicesPerPerson = numberOfSlices / numberOfPeople
            val slicesLeftOver = numberOfSlices % numberOfPeople

            // Display the results to the console.
            println("Slices per person: ${slicesPerPerson}.")
            println("Slices left over: ${slicesLeftOver}.")
        }
        catch (e: Exception) {
            println("An error occurred: ${e.message}")
        }
    }

    private fun getPositiveIntegerInput(prompt: String): Int {
        var input = 0

        // Step1: Extract common functionality into its own function.
        // Get user input via the Debug > Console tab.
        // This must run as "debug", not "run".
        println(prompt)

        // Step3: Ideally the program should not shut down if the user enters invalid input.
        // Let's add another try/catch block to handle bad user input.
        try {

            // Step4: We can still get "invalid" input that will not throw an exception.
            // For this, let's check manually if the input is in range.
            input = readln().toInt()

        }
        // Step TODO: Right now we're catching and handling all exceptions, but we should only handle
        // the ones we expect so as not to give a false message.
        catch (e: Exception) {
            // Step4: Let's add some more information to the error message.
            throw Exception("Invalid input: ${e.message}")
        }
        return input
    }

    // Step?: We went a little overboard on exceptions. Let's replace some of the try/catch blocks
    // with if statements to check for common failure scenarios.
    // Make a new file called "mainWithoutExceptions.kt" and copy the code from this file into it.
    // TODO: mainWithoutExceptions.kt
}
