//package com.example.inputvalidationandexeptions
//
//import android.os.Bundle
//import androidx.activity.ComponentActivity
//import androidx.activity.compose.setContent
//import androidx.compose.foundation.layout.Column
//import androidx.compose.foundation.layout.Row
//import androidx.compose.foundation.layout.fillMaxSize
//import androidx.compose.foundation.layout.padding
//import androidx.compose.material.*
//import androidx.compose.runtime.Composable
//import androidx.compose.runtime.mutableStateOf
//import androidx.compose.runtime.remember
//import androidx.compose.runtime.getValue
//import androidx.compose.runtime.setValue
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.unit.dp
//import com.example.inputvalidationandexeptions.ui.theme.InputValidationAndExeptionsTheme
//
//const val SLICES_PER_PIZZA = 8
//
//class MainActivityStarter : ComponentActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContent {
//            InputValidationAndExeptionsTheme {
//                // A surface container using the 'background' color from the theme
//                Surface(
//                    modifier = Modifier.fillMaxSize(),
//                    color = MaterialTheme.colors.background
//                ) {
//                    PizzaApp("Android")
//                }
//            }
//        }
//    }
//}
//
//@Composable
//fun PizzaApp(name: String) {
//    var peopleText by remember { mutableStateOf("1") }
//    var pizzaText by remember { mutableStateOf("1") }
//
//    Column(
//        horizontalAlignment = Alignment.CenterHorizontally,
//        modifier = Modifier
//            .fillMaxSize()
//            .padding(horizontal = 16.dp, vertical = 40.dp)
//    ) {
//        Row() {
//            Text("Number of people:")
//            TextField(value = peopleText, onValueChange = {peopleText = it})
//        }
//        Row() {
//            Text("Number of pizzas:")
//            TextField(value = pizzaText, onValueChange = {pizzaText = it})
//        }
//        Button(onClick = { /*TODO*/ } ) {
//            Text("Calculate")
//        }
//    }
//}